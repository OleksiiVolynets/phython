def koszt_dostawy(cena_zamowienia, darmowa_dostawa):
    koszt_dostaw=0
    dostawa=20 #cena dostawy jeżeli cena_zamowienia<=darmowa_dostawa
    if cena_zamowienia>darmowa_dostawa:
        koszt_dostaw=cena_zamowienia#jeżeli cena zamowienia jest > darmowa_dostawa, to dostawa będzie darmowa
    else:
        koszt_dostaw=cena_zamowienia+dostawa
    return koszt_dostaw
def czas_realizacki(zamowienia, czas_na_jedno):
    czas_realizacji=zamowienia*czas_na_jedno#żeby uzyskać czas realizacji to treba czas_na_jedno razy ilość zamówień
    return czas_realizacji
def wortosc_zamowien(lista_cen):
    k=0
    for i in lista_cen: #biorę każdy element z listy
        k+=i #tutaj ich dodaję
    return k