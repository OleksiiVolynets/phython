'''from zamowienia import koszt_dostawy,czas_realizacki,wortosc_zamowien
cena_zamowienia=50
darmowa_dostawa=100
print(koszt_dostawy(cena_zamowienia, darmowa_dostawa))
zamowienia=5
czas_na_jedno=20
print(czas_realizacki(zamowienia, czas_na_jedno))
lista_cen=[25,49,10]
print(wortosc_zamowien(lista_cen))
#Efekt P_UO2
lista_zamowien={"klient1":{"cola":10,"twix":20,"snickers":14},"klient2":{"cola":9,"twix":13,"snickers":17},"klient3":{"cola":16,"twix":17,"snickers":19}}
k=0#suma wszystkich cen dla jednejo klienta
m=0#suma wszystkich cen dla wszystkich klienta
sred=0#srednia cena dla wszystkich klienów
for i in lista_zamowien.values():
    for j in i.values():
        k+=j
m+=k
sred=m/3#suma wszystkich cen dla wszystkich klienta podzielić na ilość klientów
print(f"dla wszystkich klientów sredni cena zamówienia jest{sred}")'''
#Zadanie 2
#Efekt P_UO2
'''swownik={}
sk=0
k=0
while 1==1:
    print("Co chcech zrobic: ")
    print("dodać produkt")
    print("usunąć produkt")
    print("Wyświetlić wszystki zamówienia")
    print("Zakończić program")
    a=input("To co chcesz ")
    if a=="dodać produkt":
        b=input("Podaj numer zamowienia ")
        c=input("Jaka jest jego nazwa i cena podaj przez przecinek")
        sp=c.split(",")
        print(sp)
        swownik[b]=sp
        print(swownik)
    elif a=="usunąć produkt":
        b=input("Podaj numer zamowienia")
        if b in swownik:
            del swownik[b]
    elif a=="Wyświetlić wszystki zamówienia":
        for keys,values in swownik.items():
            print(f"dla {keys} zamowienia jest takie zamowienia {values}")
    elif a=="Zakończić program":
        break
print(swownik)'''
#Efekt P_U02
swownik={'1': ['cola', '6', 'twiz', '9', 'ryba', '10'],"2":['cola', '11', 'twiz', '12', 'ryba', '13']}
k=0
m=[]
a=[]
def licz(j):
    p=0
    for i in j:
        p+=int(i)
    return p

for keys,values in swownik.items():
    values=values[1::2]
    print(values)
    k=licz(values)
    m.append(k)
maxim=max(m)
print(m)
if k == maxim:
    print(f"dla {keys} jest najwięcej sprzedaży {k}")
