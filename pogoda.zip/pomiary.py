#1
def c_to_f(C):
    F=C*1.8+32
    return F
def predkosc_wiatru(v):
    w=v*3.6
    return w
def cisnienie_atmosferyczne(p):
    r=p/1.33
    return r